<?php
if (file_exists("header.php")) include("header.php");
if (file_exists("recipes_content.php")) include("recipes_content.php");
if (file_exists("footer.php")) include("footer.php");

