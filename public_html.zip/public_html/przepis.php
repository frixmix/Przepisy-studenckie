<?php
if (file_exists("header.php")) include("header.php");
if (file_exists("recipe_content.php")) include("recipe_content.php");
if (file_exists("footer.php")) include("footer.php");

