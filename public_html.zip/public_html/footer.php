<footer>
    <div class="footer-content">
        <div class="logo"></div>
        <div class="copyright">
          &copy; 2024 Przepisy studenckie
        </div>
    </div>
  </footer>
</body>
</html>
